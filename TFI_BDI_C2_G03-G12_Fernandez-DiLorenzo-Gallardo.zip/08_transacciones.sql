-- ============================================================================
-- TFI - Bases de Datos I
-- 08_transacciones.sql - Etapa 5: transacciones, manejo de errores y retry
-- ----------------------------------------------------------------------------
-- Caso de negocio: registrar una venta = insertar cabecera + linea + descontar
-- stock. Las tres operaciones deben ser atomicas: si falla una, no queda nada.
--
-- sp_registrar_venta implementa:
--   * START TRANSACTION / COMMIT / ROLLBACK
--   * SELECT ... FOR UPDATE para bloquear la fila del producto
--   * validaciones de negocio (producto inexistente, stock insuficiente)
--   * logging de cada intento en log_transacciones
--   * retry ante deadlock (ERROR 1213): hasta 2 reintentos con backoff
-- ============================================================================

USE tfi_pedidos;

-- ----------------------------------------------------------------------------
-- Tabla de auditoria de transacciones.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS log_transacciones (
    id_log        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    fecha         DATETIME(3)     NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    procedimiento VARCHAR(60)     NOT NULL,
    nivel         ENUM('INFO','WARN','ERROR') NOT NULL,
    mensaje       VARCHAR(255)    NOT NULL,
    CONSTRAINT pk_log_transacciones PRIMARY KEY (id_log)
) ENGINE=InnoDB;

-- Se limpia el log para que las capturas sean reproducibles en cada corrida.
TRUNCATE TABLE log_transacciones;

DROP PROCEDURE IF EXISTS sp_registrar_venta;
DELIMITER //
CREATE PROCEDURE sp_registrar_venta(
    IN  p_id_cliente  INT UNSIGNED,
    IN  p_id_producto INT UNSIGNED,
    IN  p_cantidad    INT,
    OUT p_id_pedido   INT UNSIGNED,
    OUT p_intentos    TINYINT,
    OUT p_resultado   VARCHAR(255)
)
BEGIN
    DECLARE v_intento  TINYINT      DEFAULT 0;
    DECLARE v_ok       BOOLEAN      DEFAULT FALSE;
    DECLARE v_deadlock BOOLEAN      DEFAULT FALSE;
    DECLARE v_msg      VARCHAR(255) DEFAULT '';
    DECLARE v_stock    INT;
    DECLARE v_precio   DECIMAL(10,2);

    SET p_id_pedido = NULL;

    reintentos: WHILE v_intento < 3 AND NOT v_ok DO
        SET v_intento  = v_intento + 1;
        SET v_deadlock = FALSE;
        SET v_msg      = '';

        intento: BEGIN
            -- Deadlock: InnoDB ya revirtio la transaccion completa.
            DECLARE EXIT HANDLER FOR 1213
            BEGIN
                ROLLBACK;
                SET v_deadlock = TRUE;
                SET v_msg = 'Deadlock detectado (ERROR 1213)';
            END;

            -- Cualquier otro error SQL: revertir y registrar el mensaje.
            DECLARE EXIT HANDLER FOR SQLEXCEPTION
            BEGIN
                GET DIAGNOSTICS CONDITION 1 v_msg = MESSAGE_TEXT;
                ROLLBACK;
            END;

            START TRANSACTION;

            SELECT stock, precio
              INTO v_stock, v_precio
              FROM producto
             WHERE id_producto = p_id_producto
               FOR UPDATE;

            IF v_stock IS NULL THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Producto inexistente';
            END IF;

            IF v_stock < p_cantidad THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stock insuficiente';
            END IF;

            INSERT INTO pedido (id_cliente, fecha, estado)
            VALUES (p_id_cliente, NOW(), 'PENDIENTE');
            SET p_id_pedido = LAST_INSERT_ID();

            INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario)
            VALUES (p_id_pedido, p_id_producto, p_cantidad, v_precio);

            UPDATE producto
               SET stock = stock - p_cantidad
             WHERE id_producto = p_id_producto;

            COMMIT;
            SET v_ok = TRUE;
        END intento;

        -- Solo se reintenta ante deadlock; un error de negocio es definitivo.
        IF NOT v_ok AND NOT v_deadlock THEN
            LEAVE reintentos;
        END IF;

        IF NOT v_ok AND v_deadlock AND v_intento < 3 THEN
            INSERT INTO log_transacciones (procedimiento, nivel, mensaje)
            VALUES ('sp_registrar_venta', 'WARN',
                    CONCAT('Reintento ', v_intento, ' por deadlock (backoff ', v_intento * 50, ' ms)'));
            DO SLEEP(v_intento * 0.05);
        END IF;
    END WHILE reintentos;

    IF v_ok THEN
        SET p_resultado = 'OK';
        INSERT INTO log_transacciones (procedimiento, nivel, mensaje)
        VALUES ('sp_registrar_venta', 'INFO',
                CONCAT('Venta OK: pedido=', p_id_pedido, ' producto=', p_id_producto,
                       ' cantidad=', p_cantidad, ' intentos=', v_intento));
    ELSE
        SET p_resultado = IF(v_deadlock, 'DEADLOCK_NO_RESUELTO',
                             CONCAT('ERROR: ', LEFT(v_msg, 200)));
        INSERT INTO log_transacciones (procedimiento, nivel, mensaje)
        VALUES ('sp_registrar_venta', 'ERROR',
                CONCAT('Venta fallida: ', v_msg, ' (intentos=', v_intento, ')'));
    END IF;

    SET p_intentos = v_intento;
END //
DELIMITER ;

-- ============================================================================
-- DEMOSTRACIONES
-- ============================================================================

-- [CAPTURA:tx_estado_inicial] Estado inicial: stock del producto 10 y ultimo pedido
SELECT id_producto, nombre, stock FROM producto WHERE id_producto = 10;
SELECT MAX(id_pedido) AS ultimo_pedido FROM pedido;

-- [CAPTURA:tx_commit] Venta exitosa (COMMIT): pedido + linea + descuento de stock
CALL sp_registrar_venta(1, 10, 2, @pedido, @intentos, @resultado);
SELECT @pedido AS pedido_creado, @intentos AS intentos, @resultado AS resultado;
SELECT id_pedido, id_cliente, fecha, estado FROM pedido WHERE id_pedido = @pedido;
SELECT id_pedido, id_producto, cantidad, precio_unitario FROM detalle_pedido WHERE id_pedido = @pedido;
SELECT stock AS stock_luego_de_la_venta FROM producto WHERE id_producto = 10;

-- [CAPTURA:tx_stock_insuficiente] Venta rechazada (ROLLBACK): stock insuficiente
CALL sp_registrar_venta(1, 10, 999999, @pedido2, @intentos2, @resultado2);
SELECT @pedido2 AS pedido_creado, @intentos2 AS intentos, @resultado2 AS resultado;
SELECT stock AS stock_intacto FROM producto WHERE id_producto = 10;

-- [CAPTURA:tx_producto_inexistente] Venta rechazada (ROLLBACK): producto inexistente
CALL sp_registrar_venta(1, 999999, 1, @pedido3, @intentos3, @resultado3);
SELECT @pedido3 AS pedido_creado, @intentos3 AS intentos, @resultado3 AS resultado;

-- [CAPTURA:tx_cliente_inexistente] Venta rechazada (ROLLBACK): FK de cliente invalida
CALL sp_registrar_venta(999999, 10, 1, @pedido4, @intentos4, @resultado4);
SELECT @pedido4 AS pedido_creado, @intentos4 AS intentos, @resultado4 AS resultado;

-- [CAPTURA:tx_rollback_manual] ROLLBACK manual: el descuento de stock no persiste
START TRANSACTION;
UPDATE producto SET stock = stock - 5 WHERE id_producto = 10;
SELECT stock AS stock_dentro_de_la_transaccion FROM producto WHERE id_producto = 10;
ROLLBACK;
SELECT stock AS stock_despues_del_rollback FROM producto WHERE id_producto = 10;

-- [CAPTURA:tx_log] Log de transacciones generado por las pruebas
SELECT id_log, fecha, nivel, mensaje
FROM log_transacciones
ORDER BY id_log DESC
LIMIT 10;

