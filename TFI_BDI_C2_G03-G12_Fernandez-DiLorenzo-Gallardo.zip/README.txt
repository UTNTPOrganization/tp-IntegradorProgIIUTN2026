=============================================================================
TFI - BASES DE DATOS I
Pedidos / ventas online - Scripts de implementacion
=============================================================================

Version: 1.0
Motor:   MySQL 8.0 (InnoDB, utf8mb4)
Base:    tfi_pedidos

-----------------------------------------------------------------------------
ORDEN DE EJECUCION
-----------------------------------------------------------------------------
Los scripts se ejecutan EN ESTE ORDEN, siempre desde una base limpia:

  01_esquema.sql          Crea la base y las 5 tablas con PK/FK/UNIQUE/CHECK.
  02_catalogos.sql        Carga las 10 categorias (y limpia las pruebas de 01).
  03_carga_masiva.sql     Genera 345.010 filas con SQL puro (WITH RECURSIVE
                          + producto cartesiano controlado).
  04_indices.sql          Crea los 7 indices de las consultas de negocio.
  05_consultas.sql        Las 4 consultas minimas + 2 adicionales.
  05_explain.sql          EXPLAIN / EXPLAIN ANALYZE con y sin indice.
  06_vistas.sql           2 vistas de negocio + 2 de ocultamiento de datos.
  07_seguridad.sql        Roles, usuarios con privilegios minimos, procedimiento
                          parametrizado y pruebas de integridad.
  08_transacciones.sql    Transaccion con COMMIT/ROLLBACK, logging y retry
                          ante deadlock (1213).
  09_concurrencia_guiada.sql  Guion de deadlock e isolacion (NO se ejecuta
                          completo: cada bloque va en una sesion distinta).

Todos los scripts son idempotentes: se pueden volver a correr en orden sin
errores (01 recrea la base desde cero; 02 y 04 usan INSERT IGNORE y control
de information_schema; 06 usa CREATE OR REPLACE VIEW; 07 usa DROP IF EXISTS).

-----------------------------------------------------------------------------
COMO EJECUTAR
-----------------------------------------------------------------------------
Con el cliente de linea de comandos, desde esta carpeta:

  mysql -h 127.0.0.1 -P 3306 -u root -p < 01_esquema.sql
  mysql -h 127.0.0.1 -P 3306 -u root -p < 02_catalogos.sql
  ...

O en MySQL Workbench:
  File > Open SQL Script > seleccionar el archivo > Execute.
  (Ejecutar en el mismo orden; no hace falta seleccionar la base a mano:
   cada script hace USE tfi_pedidos.)

Tiempo estimado de la carga completa: menos de 10 segundos en un equipo
de escritorio (la carga masiva tarda ~5 s).

-----------------------------------------------------------------------------
USUARIOS CREADOS POR 07_seguridad.sql
-----------------------------------------------------------------------------
  tfi_analista / Analista#2026   -> rol_analista
      SELECT solo sobre: vw_pedido_resumen, vw_ventas_categoria,
      vw_cliente_publico. No accede a ninguna tabla base.

  tfi_vendedor / Vendedor#2026   -> rol_vendedor
      SELECT/INSERT sobre pedido y detalle_pedido, SELECT sobre producto,
      SELECT sobre vw_cliente_operaciones y EXECUTE del procedimiento
      sp_buscar_cliente_por_dni.

  Ambos usuarios tienen USAGE (sin privilegios) por defecto y el rol se
  activa automaticamente al conectar (SET DEFAULT ROLE ALL).

-----------------------------------------------------------------------------
ESTRUCTURA DE DATOS
-----------------------------------------------------------------------------
  categoria       10 filas      catalogo de rubros
  cliente         20.000        datos personales (dni y email UNIQUE)
  producto        5.000         sku UNIQUE, stock >= 0, precio >= 0
  pedido          80.000        estado acotado por CHECK
  detalle_pedido  240.000       PK compuesta (id_pedido, id_producto)

  Total: 345.010 filas.

-----------------------------------------------------------------------------
NOTAS DE DISENO
-----------------------------------------------------------------------------
- detalle_pedido.precio_unitario guarda el precio historico del momento de la
  venta. Es una denormalizacion intencional (no un error): si el producto
  cambia de precio, las ventas viejas deben conservar su valor.
- No existe columna "total" en pedido: se calcula con
  SUM(cantidad * precio_unitario) en la vista vw_pedido_resumen.
- Las bajas de clientes y productos son logicas (activo = FALSE) para no
  romper el historial de ventas; por eso las FK usan ON DELETE RESTRICT.
- detalle_pedido usa ON DELETE CASCADE respecto de pedido: si se elimina una
  cabecera, sus lineas no tienen sentido por si solas.
- El stock es el inventario actual, no se deriva del historial de ventas.

-----------------------------------------------------------------------------
EVIDENCIAS
-----------------------------------------------------------------------------
Las capturas de pantalla de todas las etapas se generan automaticamente
desde la carpeta capturas/ (ver capturas/README.md). Cada imagen indica la
etapa, el script y la consulta que la origina.
