-- ============================================================================
-- TFI - Bases de Datos I
-- 02_catalogos.sql - Etapa 2: catalogos maestros
-- ----------------------------------------------------------------------------
-- Carga las tablas de referencia del dominio. Se ejecuta despues de
-- 01_esquema.sql y antes de 03_carga_masiva.sql.
-- Idempotente: limpia las pruebas de la Etapa 1 y usa INSERT IGNORE.
-- ============================================================================

USE tfi_pedidos;

-- ----------------------------------------------------------------------------
-- Limpieza de las filas de prueba creadas por 01_esquema.sql.
-- Se borra en orden inverso a las dependencias (hijo -> padre).
-- ----------------------------------------------------------------------------
SET SQL_SAFE_UPDATES = 0;
DELETE FROM detalle_pedido;
DELETE FROM pedido;
DELETE FROM producto WHERE sku LIKE 'SKU-TEST-%';
DELETE FROM categoria WHERE nombre = 'Accesorios';
DELETE FROM cliente WHERE dni = '30111222';

-- ----------------------------------------------------------------------------
-- CATEGORIA: 10 rubros. Es la unica tabla maestra del dominio.
-- Se fija el id explicitamente para que 03_carga_masiva.sql pueda referenciarlo
-- de forma determinista (MOD sobre el id) y el proceso sea reproducible.
-- ----------------------------------------------------------------------------
INSERT IGNORE INTO categoria (id_categoria, nombre) VALUES
    ( 1, 'Notebooks'),
    ( 2, 'Monitores'),
    ( 3, 'Perifericos'),
    ( 4, 'Almacenamiento'),
    ( 5, 'Redes'),
    ( 6, 'Audio'),
    ( 7, 'Impresion'),
    ( 8, 'Camaras'),
    ( 9, 'Componentes'),
    (10, 'Accesorios');

-- [CAPTURA:catalogos] Catalogos cargados
SELECT id_categoria, nombre
FROM categoria
ORDER BY id_categoria;
