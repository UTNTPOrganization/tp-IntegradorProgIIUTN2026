-- ============================================================================
-- TFI - Bases de Datos I
-- 04_indices.sql - Etapa 3: indices para las consultas de negocio
-- ----------------------------------------------------------------------------
-- Crea los indices que sostienen las consultas de 05_consultas.sql y las
-- mediciones de 05_explain.sql. Se ejecuta despues de la carga masiva: indexar
-- antes de cargar 345.000 filas solo hace mas lento el INSERT.
--
-- Idempotente: usa un procedimiento auxiliar que consulta information_schema
-- antes de crear cada indice (MySQL no soporta CREATE INDEX IF NOT EXISTS).
-- ============================================================================

USE tfi_pedidos;

DROP PROCEDURE IF EXISTS crear_indice;
DELIMITER //
CREATE PROCEDURE crear_indice(
    IN p_tabla      VARCHAR(64),
    IN p_indice     VARCHAR(64),
    IN p_columnas   VARCHAR(255)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE()
          AND table_name   = p_tabla
          AND index_name   = p_indice
    ) THEN
        SET @ddl = CONCAT('CREATE INDEX ', p_indice, ' ON ', p_tabla, ' (', p_columnas, ')');
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

-- Igualdad: pedidos por estado (se combina con fecha para reportes por periodo).
CALL crear_indice('pedido', 'idx_pedido_estado_fecha', 'estado, fecha');

-- Rango: pedidos por periodo.
CALL crear_indice('pedido', 'idx_pedido_fecha', 'fecha');

-- JOIN: pedidos de un cliente.
CALL crear_indice('pedido', 'idx_pedido_cliente', 'id_cliente');

-- JOIN: lineas de un producto (ranking de ventas).
CALL crear_indice('detalle_pedido', 'idx_detalle_producto', 'id_producto');

-- JOIN: productos de una categoria.
CALL crear_indice('producto', 'idx_producto_categoria', 'id_categoria');

-- Rango: productos por precio.
CALL crear_indice('producto', 'idx_producto_precio', 'precio');

-- Rango: clientes por fecha de alta.
CALL crear_indice('cliente', 'idx_cliente_fecha_alta', 'fecha_alta');

DROP PROCEDURE IF EXISTS crear_indice;

-- Actualiza estadisticas del optimizador para que EXPLAIN sea representativo.
ANALYZE TABLE cliente, producto, pedido, detalle_pedido;

-- [CAPTURA:indices] Indices creados sobre el esquema
SELECT table_name   AS tabla,
       index_name   AS indice,
       GROUP_CONCAT(column_name ORDER BY seq_in_index) AS columnas,
       non_unique   AS no_unico
FROM information_schema.statistics
WHERE table_schema = DATABASE()
  AND table_name IN ('cliente','producto','pedido','detalle_pedido')
GROUP BY table_name, index_name, non_unique
ORDER BY table_name, index_name;

-- ============================================================================
-- PARA MEDIR "SIN INDICE"
-- ----------------------------------------------------------------------------
-- Opcion A (recomendada, no destructiva): IGNORE INDEX en la consulta.
--     SELECT ... FROM pedido IGNORE INDEX (idx_pedido_fecha) WHERE fecha BETWEEN ...;
--     (es la que usa 05_explain.sql)
--
-- Opcion B (destructiva): borrar el indice, medir y volver a crearlo.
--     DROP INDEX idx_pedido_fecha ON pedido;
--     ... medir ...
--     CREATE INDEX idx_pedido_fecha ON pedido (fecha);
--
-- En ambos casos: 3 corridas por variante y se reporta la mediana.
-- ============================================================================
