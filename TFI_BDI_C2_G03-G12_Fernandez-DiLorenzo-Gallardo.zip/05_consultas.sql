-- ============================================================================
-- TFI - Bases de Datos I
-- 05_consultas.sql - Etapa 3: consultas de negocio
-- ----------------------------------------------------------------------------
-- 4 consultas minimas (2 con JOIN, 1 con GROUP BY + HAVING, 1 con subconsulta)
-- + 2 consultas adicionales que agregan valor al sistema.
-- Cada una indica su utilidad practica y la tecnica que ejercita.
-- ============================================================================

USE tfi_pedidos;

-- ----------------------------------------------------------------------------
-- Q1 [JOIN] Top 10 pedidos entregados por monto total.
-- Utilidad: detectar las ventas de mayor valor para control de fraude, logistica
-- y priorizacion de envios. Ejercita JOIN de 3 tablas + agregacion + ORDER BY.
-- ----------------------------------------------------------------------------
-- [CAPTURA:q1_join_top_pedidos] Q1 (JOIN) - Top 10 pedidos entregados por monto
SELECT
    p.id_pedido,
    CONCAT(c.nombre, ' ', c.apellido) AS cliente,
    DATE(p.fecha)                     AS fecha,
    p.estado,
    ROUND(SUM(d.cantidad * d.precio_unitario), 2) AS total
FROM pedido p
JOIN cliente c        ON c.id_cliente = p.id_cliente
JOIN detalle_pedido d ON d.id_pedido  = p.id_pedido
WHERE p.estado = 'ENTREGADO'
GROUP BY p.id_pedido, c.nombre, c.apellido, p.fecha, p.estado
ORDER BY total DESC
LIMIT 10;

-- ----------------------------------------------------------------------------
-- Q2 [JOIN] Facturacion por categoria.
-- Utilidad: saber que rubro sostiene el negocio y cual conviene promocionar.
-- Ejercita JOIN de 4 tablas + COUNT(DISTINCT) + SUM.
-- ----------------------------------------------------------------------------
-- [CAPTURA:q2_join_ventas_categoria] Q2 (JOIN) - Facturacion por categoria
SELECT
    cat.nombre                     AS categoria,
    COUNT(DISTINCT p.id_pedido)    AS pedidos,
    SUM(d.cantidad)                AS unidades,
    ROUND(SUM(d.cantidad * d.precio_unitario), 2) AS facturado
FROM pedido p
JOIN detalle_pedido d ON d.id_pedido   = p.id_pedido
JOIN producto pr      ON pr.id_producto = d.id_producto
JOIN categoria cat    ON cat.id_categoria = pr.id_categoria
WHERE p.estado <> 'CANCELADO'
GROUP BY cat.nombre
ORDER BY facturado DESC;

-- ----------------------------------------------------------------------------
-- Q3 [GROUP BY + HAVING] Clientes recurrentes de alto valor.
-- Utilidad: segmento VIP para beneficios y campanas de fidelizacion.
-- El HAVING filtra grupos ya agregados (no se puede usar WHERE para eso).
-- ----------------------------------------------------------------------------
-- [CAPTURA:q3_having_clientes_vip] Q3 (GROUP BY + HAVING) - Clientes con 10+ pedidos y mas de $500.000
SELECT
    c.id_cliente,
    CONCAT(c.nombre, ' ', c.apellido) AS cliente,
    COUNT(DISTINCT p.id_pedido)       AS pedidos,
    ROUND(SUM(d.cantidad * d.precio_unitario), 2) AS total_gastado,
    ROUND(SUM(d.cantidad * d.precio_unitario) / COUNT(DISTINCT p.id_pedido), 2) AS ticket_promedio
FROM cliente c
JOIN pedido p         ON p.id_cliente = c.id_cliente
JOIN detalle_pedido d ON d.id_pedido  = p.id_pedido
WHERE p.estado <> 'CANCELADO'
GROUP BY c.id_cliente, c.nombre, c.apellido
HAVING COUNT(DISTINCT p.id_pedido) >= 10
   AND SUM(d.cantidad * d.precio_unitario) > 500000
ORDER BY total_gastado DESC
LIMIT 10;

-- ----------------------------------------------------------------------------
-- Q4 [SUBCONSULTA] Productos por encima del precio promedio de su categoria.
-- Utilidad: detectar productos premium mal ubicados en el catalogo.
-- Usa subconsulta correlacionada: el promedio se recalcula por categoria.
-- ----------------------------------------------------------------------------
-- [CAPTURA:q4_subconsulta_premium] Q4 (SUBCONSULTA) - Productos sobre el promedio de su categoria
SELECT
    pr.sku,
    pr.nombre,
    cat.nombre AS categoria,
    pr.precio,
    (SELECT ROUND(AVG(pr2.precio), 2)
       FROM producto pr2
      WHERE pr2.id_categoria = pr.id_categoria) AS promedio_categoria
FROM producto pr
JOIN categoria cat ON cat.id_categoria = pr.id_categoria
WHERE pr.precio > (SELECT AVG(pr2.precio)
                     FROM producto pr2
                    WHERE pr2.id_categoria = pr.id_categoria)
ORDER BY pr.precio DESC
LIMIT 15;

-- ----------------------------------------------------------------------------
-- Q5 [EXTRA - ventana] Ranking mensual de facturacion.
-- Utilidad: comparar meses entre si sin perder el detalle cronologico.
-- Ejercita funcion de ventana RANK() sobre una agregacion.
-- ----------------------------------------------------------------------------
-- [CAPTURA:q5_extra_ranking_mensual] Q5 (extra) - Ranking mensual de facturacion
SELECT
    DATE_FORMAT(p.fecha, '%Y-%m') AS periodo,
    COUNT(DISTINCT p.id_pedido)   AS pedidos,
    ROUND(SUM(d.cantidad * d.precio_unitario), 2) AS facturado,
    RANK() OVER (ORDER BY SUM(d.cantidad * d.precio_unitario) DESC) AS ranking
FROM pedido p
JOIN detalle_pedido d ON d.id_pedido = p.id_pedido
WHERE p.estado <> 'CANCELADO'
GROUP BY periodo
ORDER BY periodo;

-- ----------------------------------------------------------------------------
-- Q6 [EXTRA - subconsulta] Clientes sin compras en el ultimo anio.
-- Utilidad: campana de reactivacion. NOT EXISTS corta en la primera coincidencia.
-- ----------------------------------------------------------------------------
-- [CAPTURA:q6_extra_clientes_inactivos] Q6 (extra) - Clientes sin compras desde 2024
SELECT
    c.id_cliente,
    CONCAT(c.nombre, ' ', c.apellido) AS cliente,
    c.fecha_alta,
    (SELECT MAX(p.fecha)
       FROM pedido p
      WHERE p.id_cliente = c.id_cliente) AS ultimo_pedido
FROM cliente c
WHERE NOT EXISTS (
        SELECT 1
        FROM pedido p
        WHERE p.id_cliente = c.id_cliente
          AND p.fecha >= '2024-01-01'
      )
ORDER BY c.fecha_alta
LIMIT 15;
