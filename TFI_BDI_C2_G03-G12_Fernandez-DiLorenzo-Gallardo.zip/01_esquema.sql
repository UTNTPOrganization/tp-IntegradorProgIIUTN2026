-- ============================================================================
-- TFI - Bases de Datos I
-- 01_esquema.sql - Etapa 1: modelo relacional y constraints
-- ----------------------------------------------------------------------------
-- Dominio: pedidos / ventas online.
-- Tablas: categoria, cliente, producto, pedido, detalle_pedido.
-- Motor: MySQL 8.0 (InnoDB, utf8mb4).
-- Idempotente: recrea la base desde cero.
-- ============================================================================

DROP DATABASE IF EXISTS tfi_pedidos;
CREATE DATABASE tfi_pedidos
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;

USE tfi_pedidos;

-- ----------------------------------------------------------------------------
-- CATEGORIA: catalogo de rubros de producto.
-- ----------------------------------------------------------------------------
CREATE TABLE categoria (
    id_categoria INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre       VARCHAR(60)  NOT NULL,
    CONSTRAINT pk_categoria        PRIMARY KEY (id_categoria),
    CONSTRAINT uq_categoria_nombre UNIQUE (nombre),
    CONSTRAINT chk_categoria_nombre CHECK (CHAR_LENGTH(TRIM(nombre)) >= 3)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- CLIENTE: datos personales. dni y email son identificadores de negocio (UNIQUE).
-- fecha_alta y activo permiten bajas logicas sin borrar historial de compras.
-- ----------------------------------------------------------------------------
CREATE TABLE cliente (
    id_cliente INT UNSIGNED NOT NULL AUTO_INCREMENT,
    dni        VARCHAR(8)   NOT NULL,
    nombre     VARCHAR(50)  NOT NULL,
    apellido   VARCHAR(50)  NOT NULL,
    email      VARCHAR(120) NOT NULL,
    telefono   VARCHAR(20)  NULL,
    fecha_alta DATE         NOT NULL DEFAULT (CURRENT_DATE),
    activo     BOOLEAN      NOT NULL DEFAULT TRUE,
    CONSTRAINT pk_cliente        PRIMARY KEY (id_cliente),
    CONSTRAINT uq_cliente_dni    UNIQUE (dni),
    CONSTRAINT uq_cliente_email  UNIQUE (email),
    CONSTRAINT chk_cliente_dni   CHECK (dni REGEXP '^[0-9]{7,8}$'),
    CONSTRAINT chk_cliente_email CHECK (email LIKE '%_@_%._%'),
    CONSTRAINT chk_cliente_activo CHECK (activo IN (0, 1))
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- PRODUCTO: sku es el identificador de negocio (UNIQUE).
-- stock >= 0 evita stock negativo; precio >= 0 evita precios invalidos.
-- ----------------------------------------------------------------------------
CREATE TABLE producto (
    id_producto  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    sku          VARCHAR(20)  NOT NULL,
    nombre       VARCHAR(120) NOT NULL,
    id_categoria INT UNSIGNED NOT NULL,
    precio       DECIMAL(10,2) NOT NULL,
    stock        INT          NOT NULL DEFAULT 0,
    activo       BOOLEAN      NOT NULL DEFAULT TRUE,
    CONSTRAINT pk_producto          PRIMARY KEY (id_producto),
    CONSTRAINT uq_producto_sku      UNIQUE (sku),
    CONSTRAINT fk_producto_categoria FOREIGN KEY (id_categoria)
        REFERENCES categoria (id_categoria)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_producto_precio  CHECK (precio >= 0),
    CONSTRAINT chk_producto_stock   CHECK (stock >= 0),
    CONSTRAINT chk_producto_activo  CHECK (activo IN (0, 1))
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- PEDIDO: cabecera de venta. estado acotado por CHECK (dominio cerrado).
-- Borrar un cliente con pedidos queda bloqueado por RESTRICT: se usa baja logica.
-- ----------------------------------------------------------------------------
CREATE TABLE pedido (
    id_pedido  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_cliente INT UNSIGNED NOT NULL,
    fecha      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado     VARCHAR(12)  NOT NULL DEFAULT 'PENDIENTE',
    CONSTRAINT pk_pedido         PRIMARY KEY (id_pedido),
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (id_cliente)
        REFERENCES cliente (id_cliente)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_pedido_estado CHECK (estado IN
        ('PENDIENTE','PAGADO','ENVIADO','ENTREGADO','CANCELADO')),
    CONSTRAINT chk_pedido_fecha  CHECK (fecha >= '2020-01-01 00:00:00')
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- DETALLE_PEDIDO: lineas de venta. PK compuesta (id_pedido, id_producto):
-- un producto aparece una sola vez por pedido (la cantidad va en 'cantidad').
-- precio_unitario guarda el precio historico al momento de la venta: es una
-- denormalizacion intencional, no un error de diseno.
-- ----------------------------------------------------------------------------
CREATE TABLE detalle_pedido (
    id_pedido       INT UNSIGNED  NOT NULL,
    id_producto     INT UNSIGNED  NOT NULL,
    cantidad        INT           NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT pk_detalle_pedido    PRIMARY KEY (id_pedido, id_producto),
    CONSTRAINT fk_detalle_pedido    FOREIGN KEY (id_pedido)
        REFERENCES pedido (id_pedido)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_detalle_producto  FOREIGN KEY (id_producto)
        REFERENCES producto (id_producto)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_detalle_cantidad CHECK (cantidad > 0),
    CONSTRAINT chk_detalle_precio   CHECK (precio_unitario >= 0)
) ENGINE=InnoDB;

-- ============================================================================
-- VALIDACION PRACTICA (Etapa 1)
-- 2 inserciones correctas + 2 incorrectas con errores distintos.
-- Las lineas marcadas [ERROR] estan comentadas a proposito: si se ejecutan
-- sueltas, la base las rechaza (evidencia en capturas).
-- ============================================================================

-- [CAPTURA:ok_insert_1] Insercion valida 1: cliente nuevo
INSERT INTO cliente (dni, nombre, apellido, email, telefono, fecha_alta, activo)
VALUES ('30111222', 'Lucia', 'Fernandez', 'lucia.fernandez@correo.test', '1145550001', '2024-03-15', TRUE);

-- [CAPTURA:ok_insert_2] Insercion valida 2: categoria + producto
INSERT INTO categoria (nombre) VALUES ('Accesorios');

INSERT INTO producto (sku, nombre, id_categoria, precio, stock, activo)
VALUES ('SKU-TEST-01', 'Mouse Inalambrico', LAST_INSERT_ID(), 15999.90, 25, TRUE);

-- [CAPTURA:err_unique] Insercion invalida 1: dni duplicado -> ERROR 1062 (UNIQUE)
-- [ERROR] INSERT INTO cliente (dni, nombre, apellido, email) VALUES ('30111222', 'Otro', 'Cliente', 'otro@correo.test');

-- [CAPTURA:err_check] Insercion invalida 2: precio negativo -> ERROR 3819 (CHECK)
-- [ERROR] INSERT INTO producto (sku, nombre, id_categoria, precio) VALUES ('SKU-TEST-02', 'Producto Invalido', 1, -10.00);

-- [CAPTURA:err_fk] Insercion invalida 3 (extra): pedido de cliente inexistente -> ERROR 1452 (FK)
-- [ERROR] INSERT INTO pedido (id_cliente, fecha, estado) VALUES (999999, '2025-01-10 10:00:00', 'PENDIENTE');

-- Estado final de las pruebas
-- [CAPTURA:estado_etapa1] Verificacion: filas creadas por las pruebas de la Etapa 1
SELECT 'cliente' AS tabla, COUNT(*) AS filas FROM cliente
UNION ALL SELECT 'categoria', COUNT(*) FROM categoria
UNION ALL SELECT 'producto', COUNT(*) FROM producto
UNION ALL SELECT 'pedido', COUNT(*) FROM pedido
UNION ALL SELECT 'detalle_pedido', COUNT(*) FROM detalle_pedido;
