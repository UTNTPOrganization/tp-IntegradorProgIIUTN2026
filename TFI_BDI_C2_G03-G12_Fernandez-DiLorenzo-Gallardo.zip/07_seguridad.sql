-- ============================================================================
-- TFI - Bases de Datos I
-- 07_seguridad.sql - Etapa 4: seguridad e integridad
-- ----------------------------------------------------------------------------
-- 1. Roles y usuarios con privilegios minimos (solo vistas, nunca tablas base).
-- 2. Procedimiento almacenado parametrizado, sin SQL dinamico (anti-inyeccion).
-- 3. Pruebas de integridad: PK duplicada, FK invalida, CHECK y UNIQUE.
--
-- Requiere ejecutarse como root (o usuario con privilegios de administracion).
-- Idempotente: DROP USER / DROP ROLE IF EXISTS.
-- ============================================================================

USE tfi_pedidos;

-- ============================================================================
-- 1. ROLES Y USUARIOS
-- ============================================================================

DROP USER IF EXISTS 'tfi_analista'@'localhost';
DROP USER IF EXISTS 'tfi_vendedor'@'localhost';
DROP ROLE IF EXISTS 'rol_analista';
DROP ROLE IF EXISTS 'rol_vendedor';

-- Rol de analisis: SOLO lectura de vistas agregadas y de la vista enmascarada.
CREATE ROLE 'rol_analista';
GRANT SELECT ON tfi_pedidos.vw_pedido_resumen       TO 'rol_analista';
GRANT SELECT ON tfi_pedidos.vw_ventas_categoria     TO 'rol_analista';
GRANT SELECT ON tfi_pedidos.vw_cliente_publico      TO 'rol_analista';

-- Rol de ventas: carga pedidos y consulta clientes enmascarados.
-- No puede ver la tabla cliente, ni el dni/email/telefono completos.
CREATE ROLE 'rol_vendedor';
GRANT SELECT, INSERT ON tfi_pedidos.pedido          TO 'rol_vendedor';
GRANT SELECT, INSERT ON tfi_pedidos.detalle_pedido  TO 'rol_vendedor';
GRANT SELECT         ON tfi_pedidos.producto        TO 'rol_vendedor';
GRANT SELECT         ON tfi_pedidos.vw_cliente_operaciones TO 'rol_vendedor';

-- Usuarios concretos con privilegios minimos (sin GRANT OPTION, sin DDL).
CREATE USER 'tfi_analista'@'localhost' IDENTIFIED BY 'Analista#2026'
    PASSWORD EXPIRE NEVER;
CREATE USER 'tfi_vendedor'@'localhost' IDENTIFIED BY 'Vendedor#2026'
    PASSWORD EXPIRE NEVER;

GRANT 'rol_analista' TO 'tfi_analista'@'localhost';
GRANT 'rol_vendedor' TO 'tfi_vendedor'@'localhost';

-- El rol se activa automaticamente al conectar.
SET DEFAULT ROLE ALL TO 'tfi_analista'@'localhost';
SET DEFAULT ROLE ALL TO 'tfi_vendedor'@'localhost';

FLUSH PRIVILEGES;

-- ============================================================================
-- 2. CONSULTA SEGURA (procedimiento sin SQL dinamico)
-- ----------------------------------------------------------------------------
-- El dni entra como parametro tipado y se usa en un WHERE por igualdad.
-- No hay CONCAT de SQL ni PREPARE dinamico: el motor lo trata como valor,
-- nunca como codigo. Devuelve solo datos no sensibles (dni parcial).
-- ============================================================================

DROP PROCEDURE IF EXISTS sp_buscar_cliente_por_dni;
DELIMITER //
CREATE PROCEDURE sp_buscar_cliente_por_dni(IN p_dni VARCHAR(20))
    SQL SECURITY DEFINER
    COMMENT 'Busqueda parametrizada de cliente por dni, sin SQL dinamico'
BEGIN
    SELECT
        id_cliente,
        CONCAT(LEFT(dni, 2), '***', RIGHT(dni, 1)) AS dni_parcial,
        CONCAT(nombre, ' ', apellido)              AS cliente,
        fecha_alta,
        activo
    FROM cliente
    WHERE dni = p_dni;
END //
DELIMITER ;

GRANT EXECUTE ON PROCEDURE tfi_pedidos.sp_buscar_cliente_por_dni TO 'rol_vendedor';
GRANT EXECUTE ON PROCEDURE tfi_pedidos.sp_buscar_cliente_por_dni TO 'rol_analista';

-- ============================================================================
-- 3. PRUEBAS DE INTEGRIDAD
-- ----------------------------------------------------------------------------
-- Las lineas [ERROR] estan comentadas: al ejecutarlas sueltas la base las
-- rechaza. Cada una dispara un codigo distinto.
-- ============================================================================

-- [CAPTURA:integr_ok] Prueba valida de control: el cliente 1 existe
SELECT id_cliente, dni, CONCAT(nombre, ' ', apellido) AS cliente
FROM cliente
WHERE id_cliente = 1;

-- [CAPTURA:integr_pk_duplicada] Integridad 1: PK compuesta duplicada -> ERROR 1062
-- [ERROR] INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) SELECT id_pedido, id_producto, 1, precio_unitario FROM detalle_pedido LIMIT 1;

-- [CAPTURA:integr_fk] Integridad 2: FK inexistente -> ERROR 1452
-- [ERROR] INSERT INTO pedido (id_cliente, fecha, estado) VALUES (999999, '2025-06-01 12:00:00', 'PENDIENTE');

-- [CAPTURA:integr_check] Integridad 3: cantidad 0 -> ERROR 3819
-- [ERROR] INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES (1, 1, 0, 100.00);

-- [CAPTURA:integr_unique] Integridad 4: email duplicado -> ERROR 1062
-- [ERROR] INSERT INTO cliente (dni, nombre, apellido, email) VALUES ('12345678', 'Test', 'Duplicado', (SELECT email FROM cliente WHERE id_cliente = 1));

-- ============================================================================
-- 4. PRUEBA ANTI-INYECCION
-- ----------------------------------------------------------------------------
-- Entrada maliciosa clasica: ' OR '1'='1
-- Si la consulta se armara concatenando texto, el WHERE quedaria siempre
-- verdadero y devolveria toda la tabla. Al ser un parametro tipado, el motor
-- compara el dni contra el literal completo: no hay coincidencias.
-- ============================================================================

-- [CAPTURA:inyeccion_bloqueada] Anti-inyeccion: la cadena maliciosa no devuelve filas
CALL sp_buscar_cliente_por_dni('10001641'' OR ''1''=''1');

-- [CAPTURA:inyeccion_conteo] Anti-inyeccion: la cadena se compara como valor literal (0 coincidencias)
SELECT COUNT(*) AS coincidencias
FROM cliente
WHERE dni = '10001641'' OR ''1''=''1';

-- [CAPTURA:inyeccion_control] Control: la misma busqueda con un dni valido si devuelve la fila
CALL sp_buscar_cliente_por_dni('10001641');

-- ============================================================================
-- 5. EVIDENCIA DE PRIVILEGIOS
-- ============================================================================

-- [CAPTURA:grants_analista] Privilegios efectivos del usuario de analisis
SHOW GRANTS FOR 'tfi_analista'@'localhost' USING 'rol_analista';

-- [CAPTURA:grants_vendedor] Privilegios efectivos del usuario de ventas
SHOW GRANTS FOR 'tfi_vendedor'@'localhost' USING 'rol_vendedor';

-- [CAPTURA:grants_rol_analista] Privilegios del rol de analisis
SHOW GRANTS FOR 'rol_analista';
