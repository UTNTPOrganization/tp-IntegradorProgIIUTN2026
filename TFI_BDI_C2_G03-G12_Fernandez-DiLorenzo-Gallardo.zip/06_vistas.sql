-- ============================================================================
-- TFI - Bases de Datos I
-- 06_vistas.sql - Etapas 3 y 4: vistas de negocio y vistas de ocultamiento
-- ----------------------------------------------------------------------------
-- 2 vistas de negocio (reportes) + 2 vistas que ocultan datos sensibles.
-- Las vistas de ocultamiento son la base de la seguridad de 07_seguridad.sql:
-- el usuario restringido solo recibe SELECT sobre estas vistas, nunca sobre
-- las tablas base.
-- Idempotente: CREATE OR REPLACE VIEW.
-- ============================================================================

USE tfi_pedidos;

-- ----------------------------------------------------------------------------
-- V1 [NEGOCIO] vw_pedido_resumen
-- Un renglon por pedido con cliente, cantidad de lineas y total.
-- Evita repetir el JOIN de 3 tablas en cada reporte y estandariza el calculo
-- del total (SUM(cantidad * precio_unitario)).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_pedido_resumen AS
SELECT
    p.id_pedido,
    p.fecha,
    p.estado,
    c.id_cliente,
    CONCAT(c.nombre, ' ', c.apellido) AS cliente,
    COUNT(d.id_producto)              AS lineas,
    SUM(d.cantidad)                   AS unidades,
    ROUND(SUM(d.cantidad * d.precio_unitario), 2) AS total
FROM pedido p
JOIN cliente c        ON c.id_cliente = p.id_cliente
JOIN detalle_pedido d ON d.id_pedido  = p.id_pedido
GROUP BY p.id_pedido, p.fecha, p.estado, c.id_cliente, c.nombre, c.apellido;

-- ----------------------------------------------------------------------------
-- V2 [NEGOCIO] vw_ventas_categoria
-- Facturacion y unidades por categoria, sin contar pedidos cancelados.
-- Es la vista que consume el area comercial para el tablero mensual.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_ventas_categoria AS
SELECT
    cat.id_categoria,
    cat.nombre                     AS categoria,
    COUNT(DISTINCT p.id_pedido)    AS pedidos,
    SUM(d.cantidad)                AS unidades,
    ROUND(SUM(d.cantidad * d.precio_unitario), 2) AS facturado
FROM categoria cat
JOIN producto pr      ON pr.id_categoria = cat.id_categoria
JOIN detalle_pedido d ON d.id_producto   = pr.id_producto
JOIN pedido p         ON p.id_pedido     = d.id_pedido
WHERE p.estado <> 'CANCELADO'
GROUP BY cat.id_categoria, cat.nombre;

-- ----------------------------------------------------------------------------
-- V3 [OCULTAMIENTO] vw_cliente_publico
-- Expone clientes SIN dni, con email y telefono enmascarados.
-- Es la vista que se entrega a atencion al cliente / marketing.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_cliente_publico AS
SELECT
    id_cliente,
    nombre,
    apellido,
    CONCAT(LEFT(email, 2), '***@', SUBSTRING_INDEX(email, '@', -1)) AS email_enmascarado,
    CASE
        WHEN telefono IS NULL THEN NULL
        ELSE CONCAT('***-***-', RIGHT(telefono, 4))
    END AS telefono_enmascarado,
    fecha_alta,
    activo
FROM cliente;

-- ----------------------------------------------------------------------------
-- V4 [OCULTAMIENTO] vw_cliente_operaciones
-- Para el area de ventas: identifica al cliente con el dni parcialmente
-- enmascarado y muestra su actividad comercial, sin datos de contacto.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_cliente_operaciones AS
SELECT
    c.id_cliente,
    CONCAT(LEFT(c.dni, 2), '***', RIGHT(c.dni, 1)) AS dni_parcial,
    CONCAT(c.nombre, ' ', c.apellido)               AS cliente,
    c.activo,
    COUNT(DISTINCT p.id_pedido)                     AS pedidos,
    ROUND(COALESCE(SUM(d.cantidad * d.precio_unitario), 0), 2) AS total_gastado
FROM cliente c
LEFT JOIN pedido p         ON p.id_cliente = c.id_cliente
LEFT JOIN detalle_pedido d ON d.id_pedido  = p.id_pedido
GROUP BY c.id_cliente, c.dni, c.nombre, c.apellido, c.activo;

-- ============================================================================
-- MUESTRAS DE LAS VISTAS
-- ============================================================================

-- [CAPTURA:vista_pedido_resumen] V1 - vw_pedido_resumen (primeros 10 pedidos)
SELECT * FROM vw_pedido_resumen ORDER BY id_pedido LIMIT 10;

-- [CAPTURA:vista_ventas_categoria] V2 - vw_ventas_categoria
SELECT * FROM vw_ventas_categoria ORDER BY facturado DESC;

-- [CAPTURA:vista_cliente_publico] V3 - vw_cliente_publico (datos sensibles enmascarados)
SELECT * FROM vw_cliente_publico ORDER BY id_cliente LIMIT 10;

-- [CAPTURA:vista_cliente_operaciones] V4 - vw_cliente_operaciones (dni parcial, sin contacto)
SELECT * FROM vw_cliente_operaciones ORDER BY total_gastado DESC LIMIT 10;
