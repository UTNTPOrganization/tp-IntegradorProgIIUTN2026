-- ============================================================================
-- TFI - Bases de Datos I
-- 03_carga_masiva.sql - Etapa 2: generacion de datos con SQL puro
-- ----------------------------------------------------------------------------
-- Volumen: 20.000 clientes + 5.000 productos + 80.000 pedidos
--          + 240.000 lineas de detalle = 345.010 filas (+ 10 categorias).
--
-- Mecanismo (sin procedimientos, sin bucles de cliente):
--   1. Tabla temporal "nums" con la serie 1..1000 generada con WITH RECURSIVE.
--   2. Producto cartesiano controlado de nums consigo misma para obtener los
--      rangos necesarios (200x100, 100x50, 400x200).
--   3. Derivacion determinista de atributos con MOD(), ELT() y DATE_ADD(),
--      de modo que el resultado sea reproducible (misma semilla -> mismas filas).
--
-- Integridad: los id_* se calculan dentro del rango valido de la tabla padre,
-- por lo que no puede haber FKs huerfanas. Se verifica al final.
-- ============================================================================

USE tfi_pedidos;

SET SESSION cte_max_recursion_depth = 1000000;

-- Se usa una tabla comun (no TEMPORARY) porque MySQL no permite referenciar
-- dos veces la misma tabla temporal en una consulta. Se elimina al final.
DROP TABLE IF EXISTS nums;
CREATE TABLE nums (n INT NOT NULL PRIMARY KEY) ENGINE=InnoDB;

INSERT INTO nums (n)
WITH RECURSIVE serie AS (
    SELECT 1 AS n
    UNION ALL
    SELECT n + 1 FROM serie WHERE n < 1000
)
SELECT n FROM serie;

-- ----------------------------------------------------------------------------
-- CLIENTE: 20.000 filas (200 x 100).
-- dni correlativo de 8 digitos, email unico por id, alta distribuida en 4 anos.
-- ----------------------------------------------------------------------------
INSERT INTO cliente (id_cliente, dni, nombre, apellido, email, telefono, fecha_alta, activo)
SELECT
    x.k,
    LPAD(10000000 + MOD(x.k * 7919, 89000000), 8, '0'),
    x.nombre,
    x.apellido,
    CONCAT(LOWER(x.nombre), '.', LOWER(x.apellido), x.k, '@correo.test'),
    CONCAT('11', LPAD(MOD(x.k * 7919, 100000000), 8, '0')),
    DATE_ADD('2021-01-01', INTERVAL MOD(x.k * 37, 1460) DAY),
    (MOD(x.k, 13) <> 0)
FROM (
    SELECT
        t.k,
        ELT(1 + MOD(t.k, 20),
            'Juan','Maria','Carlos','Lucia','Pedro','Sofia','Diego','Valentina','Martin','Camila',
            'Nicolas','Florencia','Santiago','Julieta','Facundo','Agustina','Matias','Micaela','Lautaro','Rocio') AS nombre,
        ELT(1 + MOD(t.k * 7, 20),
            'Gomez','Rodriguez','Fernandez','Lopez','Martinez','Perez','Garcia','Sanchez','Romero','Diaz',
            'Torres','Ruiz','Ramirez','Flores','Benitez','Acosta','Medina','Herrera','Silva','Castro') AS apellido
    FROM (
        SELECT (a.n - 1) * 100 + b.n AS k
        FROM nums a
        JOIN nums b ON b.n <= 100
        WHERE a.n <= 200
    ) t
) x
ORDER BY x.k;

-- ----------------------------------------------------------------------------
-- PRODUCTO: 5.000 filas (100 x 50).
-- id_categoria siempre entre 1 y 10 (existen las 10 categorias).
-- ----------------------------------------------------------------------------
INSERT INTO producto (id_producto, sku, nombre, id_categoria, precio, stock, activo)
SELECT
    k,
    CONCAT('SKU-', LPAD(k, 5, '0')),
    CONCAT(
        ELT(1 + MOD(k, 15),
            'Notebook','Monitor','Teclado','Mouse','Auriculares','Impresora','Router',
            'Disco SSD','Memoria RAM','Webcam','Parlante','Tablet','Cargador','Hub USB','Soporte'),
        ' ',
        ELT(1 + MOD(k * 7, 8), 'Pro','Plus','Max','Lite','X1','X2','Neo','Ultra')
    ),
    1 + MOD(k * 3, 10),
    ROUND(1000 + MOD(k * 137, 900000) / 100, 2),
    MOD(k * 29, 500) + 10,
    (MOD(k, 17) <> 0)
FROM (
    SELECT (a.n - 1) * 50 + b.n AS k
    FROM nums a
    JOIN nums b ON b.n <= 50
    WHERE a.n <= 100
) t
ORDER BY k;

-- ----------------------------------------------------------------------------
-- PEDIDO: 80.000 filas (400 x 200).
-- Fechas entre 2023-01-01 y 2024-12-31. El estado se deriva de la antiguedad:
-- los pedidos viejos ya estan entregados o cancelados; los recientes, en curso.
-- El cliente no se distribuye uniforme: 75% se reparte entre los 20.000 y 25%
-- se concentra en 2.000 clientes recurrentes (sesgo realista de negocio).
-- ----------------------------------------------------------------------------
INSERT INTO pedido (id_pedido, id_cliente, fecha, estado)
SELECT
    k,
    CASE WHEN MOD(k, 4) <> 0 THEN 1 + MOD(k * 31, 20000)
         ELSE 1 + MOD(FLOOR(k / 4) * 7, 2000)
    END,
    f.fecha,
    CASE
        WHEN f.fecha >= '2024-10-01' THEN ELT(1 + MOD(k, 3), 'PENDIENTE', 'PAGADO', 'ENVIADO')
        WHEN MOD(k, 37) = 0         THEN 'CANCELADO'
        ELSE 'ENTREGADO'
    END
FROM (
    SELECT
        (a.n - 1) * 200 + b.n AS k,
        TIMESTAMPADD(HOUR, MOD((a.n - 1) * 200 + b.n * 13, 24),
            TIMESTAMPADD(DAY, MOD((a.n - 1) * 200 + b.n * 17, 730), '2023-01-01 08:00:00')) AS fecha
    FROM nums a
    JOIN nums b ON b.n <= 200
    WHERE a.n <= 400
) f
ORDER BY k;

-- ----------------------------------------------------------------------------
-- DETALLE_PEDIDO: 240.000 filas (3 lineas por pedido).
-- El producto de cada linea se deriva del pedido y del numero de linea; las
-- lineas se separan de a 13 posiciones (mod 5000), por lo que nunca se repite
-- el producto dentro de un mismo pedido y la PK compuesta se mantiene unica.
-- precio_unitario se toma del precio actual del producto (precio historico).
-- ----------------------------------------------------------------------------
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario)
SELECT
    p.id_pedido,
    pr.id_producto,
    1 + MOD(p.id_pedido * 3 + l.linea, 5),
    pr.precio
FROM pedido p
CROSS JOIN (SELECT 1 AS linea UNION ALL SELECT 2 UNION ALL SELECT 3) l
JOIN producto pr
    ON pr.id_producto = 1 + MOD(p.id_pedido * 7 + l.linea * 13 + FLOOR(p.id_pedido / 5000) * 11, 5000);

-- ============================================================================
-- VERIFICACIONES DE CONSISTENCIA (Etapa 2)
-- ============================================================================

-- [CAPTURA:verif_conteos] V1 - Conteo de filas por tabla vs. volumen planificado
SELECT 'categoria'       AS tabla, COUNT(*) AS filas, '10'       AS planificado FROM categoria
UNION ALL SELECT 'cliente',        COUNT(*), '20000'  FROM cliente
UNION ALL SELECT 'producto',       COUNT(*), '5000'   FROM producto
UNION ALL SELECT 'pedido',         COUNT(*), '80000'  FROM pedido
UNION ALL SELECT 'detalle_pedido', COUNT(*), '240000' FROM detalle_pedido;

-- [CAPTURA:verif_fk_huerfanas] V2 - FKs huerfanas (deben dar 0 en las 4 relaciones)
SELECT 'pedido -> cliente' AS relacion, COUNT(*) AS huerfanas
FROM pedido p LEFT JOIN cliente c ON c.id_cliente = p.id_cliente
WHERE c.id_cliente IS NULL
UNION ALL
SELECT 'detalle -> pedido', COUNT(*)
FROM detalle_pedido d LEFT JOIN pedido p ON p.id_pedido = d.id_pedido
WHERE p.id_pedido IS NULL
UNION ALL
SELECT 'detalle -> producto', COUNT(*)
FROM detalle_pedido d LEFT JOIN producto pr ON pr.id_producto = d.id_producto
WHERE pr.id_producto IS NULL
UNION ALL
SELECT 'producto -> categoria', COUNT(*)
FROM producto pr LEFT JOIN categoria c ON c.id_categoria = pr.id_categoria
WHERE c.id_categoria IS NULL;

-- [CAPTURA:verif_distribucion] V3 - Distribucion por estado de pedido (% del total)
SELECT estado,
       COUNT(*) AS pedidos,
       ROUND(100 * COUNT(*) / (SELECT COUNT(*) FROM pedido), 2) AS porcentaje
FROM pedido
GROUP BY estado
ORDER BY pedidos DESC;

-- [CAPTURA:verif_rangos] V4 - Rangos de dominio respetados (fechas, precios, stock, cantidades)
SELECT
    (SELECT MIN(fecha) FROM pedido)                AS pedido_fecha_min,
    (SELECT MAX(fecha) FROM pedido)                AS pedido_fecha_max,
    (SELECT MIN(precio) FROM producto)             AS producto_precio_min,
    (SELECT MAX(precio) FROM producto)             AS producto_precio_max,
    (SELECT MIN(stock) FROM producto)              AS producto_stock_min,
    (SELECT MIN(cantidad) FROM detalle_pedido)     AS detalle_cantidad_min,
    (SELECT MAX(cantidad) FROM detalle_pedido)     AS detalle_cantidad_max;

-- [CAPTURA:verif_coherencia] V5 - Coherencia cabecera/detalle (pedidos sin lineas y total facturado)
SELECT
    (SELECT COUNT(*) FROM pedido p
      WHERE NOT EXISTS (SELECT 1 FROM detalle_pedido d WHERE d.id_pedido = p.id_pedido)) AS pedidos_sin_lineas,
    (SELECT COUNT(*) FROM detalle_pedido d
      WHERE d.precio_unitario <> (SELECT precio FROM producto pr WHERE pr.id_producto = d.id_producto)
        AND d.id_pedido <= 1000)                                                        AS precios_incoherentes_muestra,
    (SELECT ROUND(SUM(cantidad * precio_unitario), 2) FROM detalle_pedido)              AS facturacion_total;

-- La tabla auxiliar de series ya no se necesita: no forma parte del modelo.
DROP TABLE IF EXISTS nums;
