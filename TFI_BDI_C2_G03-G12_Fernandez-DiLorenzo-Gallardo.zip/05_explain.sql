-- ============================================================================
-- TFI - Bases de Datos I
-- 05_explain.sql - Etapa 3: comparacion de planes con y sin indice
-- ----------------------------------------------------------------------------
-- Tres consultas representativas, cada una en dos variantes:
--   CON indice  -> camino normal del optimizador
--   SIN indice  -> IGNORE INDEX (no destructivo; equivalente a DROP INDEX)
--
-- Metodologia de medicion (3 corridas por variante, se reporta la mediana):
--   1. Ejecutar cada consulta 3 veces seguidas.
--   2. Registrar el tiempo de ejecucion (Workbench: "Duration";
--      consola: SET profiling = 1; ... ; SHOW PROFILES;).
--   3. Ordenar las 3 mediciones y tomar la del medio (mediana).
--   4. Guardar el plan con EXPLAIN / EXPLAIN ANALYZE para justificar la
--      diferencia (tipo de acceso, filas examinadas, uso de indice).
-- La tabla resumen de tiempos se genera en capturas/ (ver README de capturas).
-- ============================================================================

USE tfi_pedidos;

-- ============================================================================
-- E1 - IGUALDAD: pedidos en estado CANCELADO
-- Indice: idx_pedido_estado_fecha (estado, fecha)
-- ============================================================================

-- [CAPTURA:explain_e1_con] E1 igualdad - EXPLAIN con indice
EXPLAIN
SELECT id_pedido, id_cliente, fecha, estado
FROM pedido
WHERE estado = 'CANCELADO';

-- [CAPTURA:analyze_e1_con] E1 igualdad - EXPLAIN ANALYZE con indice
EXPLAIN ANALYZE
SELECT id_pedido, id_cliente, fecha, estado
FROM pedido
WHERE estado = 'CANCELADO';

-- [CAPTURA:analyze_e1_sin] E1 igualdad - EXPLAIN ANALYZE sin indice (IGNORE INDEX)
EXPLAIN ANALYZE
SELECT id_pedido, id_cliente, fecha, estado
FROM pedido IGNORE INDEX (idx_pedido_estado_fecha)
WHERE estado = 'CANCELADO';

-- ============================================================================
-- E2 - RANGO: pedidos de marzo 2024
-- Indice: idx_pedido_fecha (fecha)
-- ============================================================================

-- [CAPTURA:explain_e2_con] E2 rango - EXPLAIN con indice
EXPLAIN
SELECT id_pedido, id_cliente, fecha
FROM pedido
WHERE fecha BETWEEN '2024-03-01 00:00:00' AND '2024-03-31 23:59:59';

-- [CAPTURA:analyze_e2_con] E2 rango - EXPLAIN ANALYZE con indice
EXPLAIN ANALYZE
SELECT id_pedido, id_cliente, fecha
FROM pedido
WHERE fecha BETWEEN '2024-03-01 00:00:00' AND '2024-03-31 23:59:59';

-- [CAPTURA:analyze_e2_sin] E2 rango - EXPLAIN ANALYZE sin indice (IGNORE INDEX)
EXPLAIN ANALYZE
SELECT id_pedido, id_cliente, fecha
FROM pedido IGNORE INDEX (idx_pedido_fecha)
WHERE fecha BETWEEN '2024-03-01 00:00:00' AND '2024-03-31 23:59:59';

-- ============================================================================
-- E3 - JOIN: pedidos de los primeros 500 clientes
-- Indice: idx_pedido_cliente (id_cliente)
-- ============================================================================

-- [CAPTURA:explain_e3_con] E3 JOIN - EXPLAIN con indice
EXPLAIN
SELECT c.id_cliente, COUNT(p.id_pedido) AS pedidos
FROM cliente c
JOIN pedido p ON p.id_cliente = c.id_cliente
WHERE c.id_cliente BETWEEN 1 AND 500
GROUP BY c.id_cliente;

-- [CAPTURA:analyze_e3_con] E3 JOIN - EXPLAIN ANALYZE con indice
EXPLAIN ANALYZE
SELECT c.id_cliente, COUNT(p.id_pedido) AS pedidos
FROM cliente c
JOIN pedido p ON p.id_cliente = c.id_cliente
WHERE c.id_cliente BETWEEN 1 AND 500
GROUP BY c.id_cliente;

-- [CAPTURA:analyze_e3_sin] E3 JOIN - EXPLAIN ANALYZE sin indice (IGNORE INDEX)
EXPLAIN ANALYZE
SELECT c.id_cliente, COUNT(p.id_pedido) AS pedidos
FROM cliente c
JOIN pedido p IGNORE INDEX (idx_pedido_cliente) ON p.id_cliente = c.id_cliente
WHERE c.id_cliente BETWEEN 1 AND 500
GROUP BY c.id_cliente;
