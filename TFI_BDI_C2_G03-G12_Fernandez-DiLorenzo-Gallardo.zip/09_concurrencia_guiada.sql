-- ============================================================================
-- TFI - Bases de Datos I
-- 09_concurrencia_guiada.sql - Etapa 5: guion de pruebas de concurrencia
-- ----------------------------------------------------------------------------
-- IMPORTANTE: este archivo NO se ejecuta completo de una vez.
-- Cada bloque marcado "SESION A" y "SESION B" va en una pestaña/consola
-- distinta, y los pasos se ejecutan EN EL ORDEN indicado (1, 2, 3, 4).
--
-- Las capturas de esta etapa se generan automaticamente con dos conexiones
-- reales (ver capturas/generar_capturas.py), que ejecutan exactamente estos
-- mismos pasos.
--
-- Entorno: MySQL 8.0, InnoDB, autocommit = 1.
-- ============================================================================

USE tfi_pedidos;

-- ============================================================================
-- PARTE A - DEADLOCK CON DOS SESIONES
-- ----------------------------------------------------------------------------
-- Objetivo: que dos transacciones se bloqueen mutuamente y que InnoDB aborte
-- una de ellas con ERROR 1213 (SQLSTATE 40001).
--
-- Se usan dos productos distintos para que cada sesion tome primero un lock
-- diferente y despues pida el del otro.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- PASO 1 - SESION A: abre transaccion y bloquea el producto 1
-- ----------------------------------------------------------------------------
-- START TRANSACTION;
-- SELECT id_producto, stock FROM producto WHERE id_producto = 1 FOR UPDATE;
--   -> 1 fila (lock exclusivo sobre el producto 1)

-- ----------------------------------------------------------------------------
-- PASO 2 - SESION B: abre transaccion y bloquea el producto 2
-- ----------------------------------------------------------------------------
-- START TRANSACTION;
-- SELECT id_producto, stock FROM producto WHERE id_producto = 2 FOR UPDATE;
--   -> 1 fila (lock exclusivo sobre el producto 2)

-- ----------------------------------------------------------------------------
-- PASO 3 - SESION A: pide el producto 2 (queda esperando a B)
-- ----------------------------------------------------------------------------
-- UPDATE producto SET stock = stock - 1 WHERE id_producto = 2;
--   -> queda en espera (B tiene el lock)

-- ----------------------------------------------------------------------------
-- PASO 4 - SESION B: pide el producto 1 -> DEADLOCK
-- ----------------------------------------------------------------------------
-- UPDATE producto SET stock = stock - 1 WHERE id_producto = 1;
--   -> ERROR 1213 (40001): Deadlock found when trying to get lock;
--      try restarting transaction
--   InnoDB elige esta transaccion como victima y la revierte completa.

-- ----------------------------------------------------------------------------
-- PASO 5 - SESION A: su operacion se destraba y confirma
-- ----------------------------------------------------------------------------
-- COMMIT;

-- ----------------------------------------------------------------------------
-- PASO 6 - SESION B: verificacion de que su transaccion quedo revertida
-- ----------------------------------------------------------------------------
-- SELECT id_producto, stock FROM producto WHERE id_producto IN (1, 2);
--   -> el stock del producto 2 NO cambio (rollback automatico)
-- ROLLBACK;   -- por las dudas, la transaccion ya estaba cerrada

-- ============================================================================
-- PARTE B - NIVELES DE AISLAMIENTO: READ COMMITTED vs REPEATABLE READ
-- ----------------------------------------------------------------------------
-- Se compara una LECTURA NO REPETIBLE: la sesion A lee una fila, la sesion B
-- la modifica y confirma, y A vuelve a leer.
--   REPEATABLE READ  -> A sigue viendo el valor viejo (snapshot de la tx)
--   READ COMMITTED   -> A ve el valor nuevo (snapshot por sentencia)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- B.1 - REPEATABLE READ (nivel por defecto de MySQL)
-- ----------------------------------------------------------------------------
-- SESION A:
--   SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
--   START TRANSACTION;
--   SELECT estado FROM pedido WHERE id_pedido = 1;   -- ENTREGADO
--
-- SESION B:
--   UPDATE pedido SET estado = 'CANCELADO' WHERE id_pedido = 1;
--   COMMIT;
--
-- SESION A:
--   SELECT estado FROM pedido WHERE id_pedido = 1;   -- sigue ENTREGADO
--   COMMIT;
--
-- Restauracion:
--   UPDATE pedido SET estado = 'ENTREGADO' WHERE id_pedido = 1;

-- ----------------------------------------------------------------------------
-- B.2 - READ COMMITTED
-- ----------------------------------------------------------------------------
-- SESION A:
--   SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
--   START TRANSACTION;
--   SELECT estado FROM pedido WHERE id_pedido = 1;   -- ENTREGADO
--
-- SESION B:
--   UPDATE pedido SET estado = 'CANCELADO' WHERE id_pedido = 1;
--   COMMIT;
--
-- SESION A:
--   SELECT estado FROM pedido WHERE id_pedido = 1;   -- ahora CANCELADO
--   COMMIT;
--
-- Restauracion:
--   UPDATE pedido SET estado = 'ENTREGADO' WHERE id_pedido = 1;

-- ----------------------------------------------------------------------------
-- B.3 - Verificacion del nivel configurado
-- ----------------------------------------------------------------------------
-- SELECT @@transaction_isolation;                 -- global
-- SELECT @@session.transaction_isolation;         -- de la sesion actual

-- ============================================================================
-- PARTE C - CARGA CONCURRENTE (OPCIONAL): mysqlslap
-- ----------------------------------------------------------------------------
-- Ejecutar desde una terminal (no desde el cliente SQL):
--
--   mysqlslap --host=127.0.0.1 --port=3307 --user=root --password= ^
--     --concurrency=10 --iterations=3 --number-of-queries=300 ^
--     --query="UPDATE producto SET stock = stock - 1 WHERE id_producto = FLOOR(1 + RAND()*5000)" ^
--     --create-schema=tfi_pedidos
--
-- Interpretacion: con 10 clientes concurrentes sobre 5.000 filas se observan
-- esperas de lock; el tiempo promedio por consulta sube respecto de la
-- ejecucion secuencial. No se busca un numero exacto, sino mostrar contencion.
-- ============================================================================

-- ============================================================================
-- PARTE D - OBSERVACIONES ESPERADAS (para el informe)
-- ----------------------------------------------------------------------------
-- 1. El deadlock no es un error de programacion: es un conflicto de orden de
--    acceso. La solucion de fondo es tomar los locks siempre en el mismo orden
--    (por ejemplo, ordenar los id_producto antes de actualizar).
-- 2. InnoDB revierte la transaccion victima completa; por eso el reintento
--    debe empezar con un START TRANSACTION nuevo, no continuar la anterior.
-- 3. La diferencia entre READ COMMITTED y REPEATABLE READ se ve en la segunda
--    lectura de la sesion A: con el primero cambia, con el segundo no.
-- 4. Los indices reducen la contencion porque el lock se toma sobre menos
--    filas (el motor no necesita recorrer/bloquear rangos completos).
-- ============================================================================
